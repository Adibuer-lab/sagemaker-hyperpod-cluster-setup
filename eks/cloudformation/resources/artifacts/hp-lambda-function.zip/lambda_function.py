import boto3
import botocore
import cfnresponse
import os
import json
import yaml

from botocore.exceptions import ClientError

class NoAliasDumper(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True
        
def lambda_handler(event, context):
    try:
        print(f"Event received: {json.dumps(event)}")
        request_type = event['RequestType']

        if request_type == 'Create':
            response_data = on_create(event)
        elif request_type == 'Update':
            response_data = on_create(event)
        elif request_type == 'Delete':
            response_data = on_delete(event)
        else:
            raise ValueError(f"Unsupported request type: {request_type}")

        cfnresponse.send(event, context, cfnresponse.SUCCESS, response_data)
    except Exception as e:
        print(f"Exception: {str(e)}")
        cfnresponse.send(event, context, cfnresponse.FAILED, {'Reason': str(e)})

# SSM client for reading parameters
ssm_client = boto3.client('ssm')

def get_ssm_parameter(param_name):
    """Get a parameter value from SSM Parameter Store"""
    try:
        response = ssm_client.get_parameter(Name=param_name)
        return response['Parameter']['Value']
    except Exception as e:
        print(f"Warning: Could not read SSM parameter {param_name}: {e}")
        return '[]'

def combine_settings(settings_type="instance-group-settings"):
    """
    Read combined settings from SSM Parameter Store
    
    Parameters:
    settings_type (str): "instance-group-settings" or "rig-settings"
    
    Returns:
    list: Combined settings from SSM parameter
    """
    # Get SSM param name from env var
    if settings_type == "instance-group-settings":
        param_name = os.environ.get('INSTANCE_GROUP_SETTINGS_SSM_PARAM', '')
    else:
        param_name = os.environ.get('RIG_SETTINGS_SSM_PARAM', '')
    
    if not param_name:
        print(f"Warning: SSM param not set for {settings_type}")
        return []
    
    param_value = get_ssm_parameter(param_name)
    
    if not param_value or param_value == '[]':
        return []
    
    try:
        settings = json.loads(param_value)
        if isinstance(settings, list):
            print(f"Loaded {len(settings)} settings from {param_name}")
            return settings
        else:
            print(f"Warning: Expected list from {param_name}, got {type(settings)}")
            return []
    except json.JSONDecodeError as e:
        print(f"Warning: Could not parse {param_name} as JSON: {e}")
        return []

def enrich_instance_groups(instance_groups, isRig=False):
    """
    Enrich instance groups with additional configuration
    
    Parameters:
    instance_groups (list): List of instance group configurations to enrich
    isRig (bool): Whether this is a restricted instance group (default: False)
    """
    sagemaker_iam_role_name = os.environ.get('SAGEMAKER_IAM_ROLE_NAME')
    
    # Parse security group IDs for potential OverrideVpcConfig
    security_group_ids_str = os.environ.get('SECURITY_GROUP_IDS', '')
    security_group_ids = security_group_ids_str.split(',') if security_group_ids_str and ',' in security_group_ids_str else [security_group_ids_str] if security_group_ids_str else []
    
    # Parse subnet IDs
    private_subnet_ids_str = os.environ.get('PRIVATE_SUBNET_IDS', '')
    private_subnet_ids = private_subnet_ids_str.split(',') if private_subnet_ids_str and ',' in private_subnet_ids_str else [private_subnet_ids_str] if private_subnet_ids_str else []
    
    # Check if any instance group has TargetAvailabilityZoneId
    has_target_az = any('TargetAvailabilityZoneId' in group for group in instance_groups)
    
    # Get subnet to AZ mapping from AWS if needed and if we have subnets
    subnet_to_az_mapping = {}
    if has_target_az and private_subnet_ids:
        try:
            ec2 = boto3.client('ec2')
            response = ec2.describe_subnets(SubnetIds=private_subnet_ids)
            for subnet in response.get('Subnets', []):
                subnet_to_az_mapping[subnet['SubnetId']] = subnet['AvailabilityZoneId']
            print(f"Retrieved subnet to AZ mapping: {subnet_to_az_mapping}")
        except Exception as e:
            print(f"Warning: Could not retrieve subnet to AZ mapping: {str(e)}")
    
    for instance_group in instance_groups:
        # Only add parameters if they are provided and not already in the configuration
        if sagemaker_iam_role_name and 'ExecutionRole' not in instance_group:
            instance_group['ExecutionRole'] = sagemaker_iam_role_name
            
        # Add lifecycle script configuration if not a RIG and not already present
        if not isRig:
            s3_bucket_name = os.environ.get('S3_BUCKET_NAME')
            on_create_path = os.environ.get('ON_CREATE_PATH')
            if s3_bucket_name and on_create_path and 'LifeCycleConfig' not in instance_group:
                # Parse the on_create_path to separate path and filename
                path_parts = on_create_path.rsplit('/', 1)
                
                # If there's a path component, add it to the SourceS3Uri
                if len(path_parts) > 1:
                    path, filename = path_parts
                    instance_group['LifeCycleConfig'] = {
                        'SourceS3Uri': f's3://{s3_bucket_name}/{path}',
                        'OnCreate': f'{filename}'
                    }
                else:
                    # No path component, just a filename
                    filename = path_parts[0]
                    instance_group['LifeCycleConfig'] = {
                        'SourceS3Uri': f's3://{s3_bucket_name}',
                        'OnCreate': f'{filename}'
                    }
        # Check if OverrideVpcConfig already exists
        if 'OverrideVpcConfig' in instance_group:
            # Merge cluster-level SecurityGroupIds with existing ones (deduplicated)
            existing_sgs = instance_group['OverrideVpcConfig'].get('SecurityGroupIds', [])
            merged_sgs = list(set(existing_sgs + security_group_ids))
            instance_group['OverrideVpcConfig']['SecurityGroupIds'] = merged_sgs
            print(f"Merged SecurityGroupIds for instance group: {merged_sgs}")
        
        # Check if instance group has TargetAvailabilityZoneId
        if 'TargetAvailabilityZoneId' in instance_group:
            # Check if both subnet_to_az_mapping and security_group_ids exist
            if not subnet_to_az_mapping or not security_group_ids:
                raise ValueError("When using TargetAvailabilityZoneId, both subnet mappings and security group IDs must be provided")
            
            target_az = instance_group['TargetAvailabilityZoneId']
            print(f"Instance group has TargetAvailabilityZoneId: {target_az}")
            
            # Find the first subnet in the target AZ
            target_subnet = None
            for subnet_id, az in subnet_to_az_mapping.items():
                if az == target_az:
                    target_subnet = subnet_id
                    break
            
            if target_subnet:
                print(f"Found subnet {target_subnet} in AZ {target_az}")
                
                # Check if OverrideVpcConfig already exists
                if 'OverrideVpcConfig' in instance_group:
                    # Merge cluster-level SecurityGroupIds with existing ones (deduplicated)
                    existing_sgs = instance_group['OverrideVpcConfig'].get('SecurityGroupIds', [])
                    merged_sgs = list(set(existing_sgs + security_group_ids))
                    instance_group['OverrideVpcConfig']['SecurityGroupIds'] = merged_sgs
                    
                    # Update the Subnets with the target subnet
                    instance_group['OverrideVpcConfig']['Subnets'] = [target_subnet]
                    print(f"Updated OverrideVpcConfig with merged SGs: {instance_group['OverrideVpcConfig']}")
                else:
                    # Create new OverrideVpcConfig
                    instance_group['OverrideVpcConfig'] = {
                        'SecurityGroupIds': security_group_ids,
                        'Subnets': [target_subnet]
                    }
                    print(f"Created new OverrideVpcConfig: {instance_group['OverrideVpcConfig']}")
                
                # Remove the TargetAvailabilityZoneId key after processing to prevent it from being sent to the API
                del instance_group['TargetAvailabilityZoneId']
                print(f"Removed TargetAvailabilityZoneId from instance group after processing")
            else:
                print(f"Warning: No subnet found in AZ {target_az}")
                del instance_group['TargetAvailabilityZoneId']
                print(f"Removed TargetAvailabilityZoneId from instance group after processing")
    
    return instance_groups

def filter_instance_groups_by_az_availability(instance_groups):
    """
    Filter out instance groups whose instance type is not available in their target AZ.
    
    Each instance group has an InstanceType and OverrideVpcConfig.Subnets specifying the subnet/AZ.
    We check if the instance type is offered in that AZ and skip groups where it's not.
    """
    if not instance_groups:
        return instance_groups
    
    ec2 = boto3.client('ec2')
    
    # Build cache of instance type -> available AZs
    instance_type_az_cache = {}
    
    # Get unique instance types
    instance_types = set()
    for ig in instance_groups:
        if 'InstanceType' in ig:
            # Convert ml.* to EC2 instance type
            ml_type = ig['InstanceType']
            ec2_type = ml_type.replace('ml.', '') if ml_type.startswith('ml.') else ml_type
            instance_types.add(ec2_type)
    
    # Query availability for each instance type
    for ec2_type in instance_types:
        try:
            response = ec2.describe_instance_type_offerings(
                LocationType='availability-zone',
                Filters=[{'Name': 'instance-type', 'Values': [ec2_type]}]
            )
            available_azs = {o['Location'] for o in response.get('InstanceTypeOfferings', [])}
            instance_type_az_cache[ec2_type] = available_azs
            print(f"Instance type {ec2_type} available in AZs: {available_azs}")
        except Exception as e:
            print(f"Warning: Could not check availability for {ec2_type}: {e}")
            instance_type_az_cache[ec2_type] = None  # None means skip filtering for this type
    
    # Get subnet -> AZ mapping for subnets in instance groups
    subnet_ids = set()
    for ig in instance_groups:
        if 'OverrideVpcConfig' in ig and 'Subnets' in ig['OverrideVpcConfig']:
            subnet_ids.update(ig['OverrideVpcConfig']['Subnets'])
    
    subnet_to_az = {}
    if subnet_ids:
        try:
            response = ec2.describe_subnets(SubnetIds=list(subnet_ids))
            for subnet in response.get('Subnets', []):
                subnet_to_az[subnet['SubnetId']] = subnet['AvailabilityZone']
            print(f"Subnet to AZ mapping: {subnet_to_az}")
        except Exception as e:
            print(f"Warning: Could not get subnet AZ mapping: {e}")
    
    # Filter instance groups
    filtered_groups = []
    for ig in instance_groups:
        ig_name = ig.get('InstanceGroupName', 'unknown')
        ml_type = ig.get('InstanceType', '')
        ec2_type = ml_type.replace('ml.', '') if ml_type.startswith('ml.') else ml_type
        
        # Get the AZ for this instance group
        subnets = ig.get('OverrideVpcConfig', {}).get('Subnets', [])
        if not subnets:
            # No subnet specified, keep the group
            filtered_groups.append(ig)
            continue
        
        subnet_id = subnets[0]  # Instance groups typically have one subnet
        az = subnet_to_az.get(subnet_id)
        
        if not az:
            print(f"Warning: Could not determine AZ for instance group {ig_name}, keeping it")
            filtered_groups.append(ig)
            continue
        
        # Check if instance type is available in this AZ
        available_azs = instance_type_az_cache.get(ec2_type)
        if available_azs is None:
            # Couldn't check availability, keep the group
            filtered_groups.append(ig)
            continue
        
        if az in available_azs:
            filtered_groups.append(ig)
            print(f"Instance group {ig_name} ({ml_type} in {az}): INCLUDED")
        else:
            print(f"Instance group {ig_name} ({ml_type} in {az}): EXCLUDED - instance type not available in AZ")
    
    print(f"Filtered instance groups: {len(filtered_groups)} of {len(instance_groups)} kept")
    return filtered_groups

def get_tiered_storage_config_from_env():
    """
    Get tiered storage configuration from environment variables
    
    Expected format:
    {
        "InstanceMemoryAllocationPercentage": Integer (0-100),
        "Mode": String ("Enabled" or "Disabled")
    }
    
    Returns:
    dict: Tiered storage configuration dictionary, or None if not provided or invalid
    """
    tiered_storage_config_str = os.environ.get('TIERED_STORAGE_CONFIG', '')
    
    if tiered_storage_config_str:
        try:
            tiered_storage_config = json.loads(tiered_storage_config_str)
            print(f"Parsed tiered storage config: {tiered_storage_config}")
            
            # Validate the structure
            if not isinstance(tiered_storage_config, dict):
                print(f"Error: TieredStorageConfig must be a dictionary, got {type(tiered_storage_config)}")
                return None
            
            # Validate required fields
            if 'InstanceMemoryAllocationPercentage' in tiered_storage_config:
                percentage = tiered_storage_config['InstanceMemoryAllocationPercentage']
                if not isinstance(percentage, int) or percentage < 0 or percentage > 100:
                    print(f"Error: InstanceMemoryAllocationPercentage must be an integer between 0 and 100, got {percentage}")
                    return None
            
            if 'Mode' in tiered_storage_config:
                mode = tiered_storage_config['Mode']
                if mode not in ['Enable', 'Disable']:
                    print(f"Error: Mode must be 'Enable' or 'Disable', got {mode}")
                    return None
            
            # Check for unexpected fields
            valid_fields = {'InstanceMemoryAllocationPercentage', 'Mode'}
            unexpected_fields = set(tiered_storage_config.keys()) - valid_fields
            if unexpected_fields:
                print(f"Warning: Unexpected fields in TieredStorageConfig: {unexpected_fields}")
            
            return tiered_storage_config
        except json.JSONDecodeError as e:
            print(f"Error parsing tiered storage config JSON: {str(e)}")
            return None
    
    return None

def get_tags_from_env():
    """
    Get tags from environment variables and automatically add required SageMaker tag for HPTO

    - In JSON format: `CLUSTER_TAGS=[{"Key":"Environment","Value":"Production"}]`
    - Or as key-value pairs: `CLUSTER_TAGS=Environment=Production,Team=MLOps`
    
    Returns:
    list: List of tags dictionaries with Key and Value pairs
    """
    tags = []
    tags_str = os.environ.get('CLUSTER_TAGS', '')
    
    if tags_str:
        try:
            # Try parsing as JSON
            tag_list = json.loads(tags_str)
            if isinstance(tag_list, list):
                tags = tag_list
            elif isinstance(tag_list, dict):
                # Convert dict format to list of Key/Value dictionaries
                tags = [{'Key': k, 'Value': v} for k, v in tag_list.items()]
        except json.JSONDecodeError:
            # If not valid JSON, try parsing as comma-separated key=value pairs
            try:
                tag_pairs = tags_str.split(',')
                for pair in tag_pairs:
                    if '=' in pair:
                        key, value = pair.split('=', 1)
                        tags.append({'Key': key.strip(), 'Value': value.strip()})
            except Exception as e:
                print(f"Error parsing tags string: {str(e)}")
    
    # Check if HPTO is enabled and automatically add SageMaker=true tag if needed
    # The main stack only passes 'true' when EnableHPTrainingOperatorFeatureCondition is met
    is_hpto_enabled = os.environ.get('ENABLE_HP_TRAINING_OPERATOR_FEATURE', 'false').lower() == 'true'
    
    if is_hpto_enabled:
        # Check if SageMaker tag already exists
        sagemaker_tag_exists = False
        for tag in tags:
            if tag.get('Key') == 'SageMaker':
                sagemaker_tag_exists = True
                if tag.get('Value') != 'true':
                    print(f"Warning: SageMaker tag exists with value '{tag.get('Value')}', but HPTO requires 'true'")
                    # Update the existing tag to 'true'
                    tag['Value'] = 'true'
                    print("Updated SageMaker tag value to 'true' for HPTO compatibility")
                else:
                    print("SageMaker=true tag already present")
                break
        
        # Add SageMaker=true tag if it doesn't exist
        if not sagemaker_tag_exists:
            tags.append({'Key': 'SageMaker', 'Value': 'true'})
            print("Added required SageMaker=true tag as HP training operator requires it.")
    
    return tags

def create_hyperpod_cluster(instance_groups):
    """
    Create a SageMaker HyperPod cluster
    """    
    # Get cluster parameters from environment variables
    cluster_name = os.environ.get('HYPER_POD_CLUSTER_NAME')
    if not cluster_name:
        raise ValueError("HYPER_POD_CLUSTER_NAME environment variable is required")
    
    node_recovery = os.environ.get('NODE_RECOVERY')
    if not node_recovery:
        raise ValueError("NODE_RECOVERY environment variable is required")
    if node_recovery not in ['Automatic', 'None']:
        raise ValueError("NODE_RECOVERY must be either 'Automatic' or 'None'")
        
    # Check if we're using SLURM orchestrator
    orchestrator_type = __get_orchestrator_type()
    if orchestrator_type == 'SLURM':
        # For SLURM orchestrator, upload provisioning parameters JSON first
        upload_slurm_provisioning_parameters_json(instance_groups)
        
        # Remove InstanceGroupType from instance groups for SLURM
        if instance_groups:
            for instance_group in instance_groups:
                if 'InstanceGroupType' in instance_group:
                    del instance_group['InstanceGroupType']
    

    # Parse security group IDs more robustly
    security_group_ids_str = os.environ.get('SECURITY_GROUP_IDS', '')
    security_group_ids = security_group_ids_str.split(',') if security_group_ids_str and ',' in security_group_ids_str else [security_group_ids_str] if security_group_ids_str else []
    
    # Parse subnet IDs more robustly 
    private_subnet_ids_str = os.environ.get('PRIVATE_SUBNET_IDS', '')
    private_subnet_ids = private_subnet_ids_str.split(',') if private_subnet_ids_str and ',' in private_subnet_ids_str else [private_subnet_ids_str] if private_subnet_ids_str else []
    
    # Validate VPC configuration
    if not security_group_ids and orchestrator_type == 'EKS':
        raise ValueError("At least one security group ID is required")
    if not private_subnet_ids and orchestrator_type == 'EKS':
        raise ValueError("At least one subnet ID is required")
    
    # Create cluster using SageMaker API
    print(f"Creating HyperPod cluster: {cluster_name}")
    create_params = {
        'ClusterName': cluster_name,
        'NodeRecovery': node_recovery
    }
    
    # Only include VpcConfig if we have subnets
    if private_subnet_ids:
        vpc_config = {
            'SecurityGroupIds': security_group_ids,
            'Subnets': private_subnet_ids
        }
        create_params['VpcConfig'] = vpc_config
    
    # Only add orchestrator for EKS type (not for SLURM)
    if orchestrator_type != 'SLURM':
        eks_cluster_arn = os.environ.get('EKS_CLUSTER_ARN')
        if not eks_cluster_arn:
            raise ValueError("EKS_CLUSTER_ARN environment variable is required")
        orchestrator = {
            'Eks': {
                'ClusterArn': eks_cluster_arn
            }
        }
        create_params['Orchestrator'] = orchestrator
    
    # Only add instance groups if they exist
    if instance_groups:
        create_params['InstanceGroups'] = instance_groups
    
    # Get tags if available
    tags = get_tags_from_env()
    if tags:
        create_params['Tags'] = tags
        print(f"Adding tags to cluster: {tags}")
    
    # Get restricted instance groups if available
    rig_groups = combine_settings("rig-settings")
    if rig_groups:
        rig_groups = enrich_instance_groups(rig_groups, isRig=True)  # Only add execution role
        create_params['RestrictedInstanceGroups'] = rig_groups

    # Get tiered storage configuration if available (only for EKS orchestrator)
    if orchestrator_type != 'SLURM':
        tiered_storage_config = get_tiered_storage_config_from_env()
        if tiered_storage_config:
            create_params['TieredStorageConfig'] = tiered_storage_config
            print(f"Adding tiered storage config to EKS cluster: {tiered_storage_config}")
    else:
        # Log warning if TieredStorageConfig is provided for SLURM
        if os.environ.get('TIERED_STORAGE_CONFIG', ''):
            print("Warning: TieredStorageConfig is only supported for EKS-based HyperPod clusters and will be ignored for SLURM clusters")

    if orchestrator_type != 'SLURM':
        node_provisioning_mode = os.environ.get('NODE_PROVISIONING_MODE')
        if node_provisioning_mode and node_provisioning_mode == 'Continuous':
            create_params['NodeProvisioningMode'] = node_provisioning_mode;
            autoscaler_type = os.environ.get('AUTOSCALER_TYPE')
            if autoscaler_type != 'None':
                create_params['AutoScaling'] = {
                    'Mode': 'Enable',
                    'AutoScalerType': autoscaler_type
                }
                create_params['ClusterRole'] = os.environ.get('CLUSTER_ROLE')

        
    print(f"Creating yaml with parameters: {create_params}")
    yaml_str = generate_cluster_template_yaml(create_params)
    template_url = upload_cluster_template_to_s3(yaml_str)        
         
    return {
        'ClusterName': cluster_name,
        'TemplateUrl': template_url,    
    }

def delete_hyperpod_cluster():
    """
    Delete a SageMaker HyperPod cluster and wait until it's fully deleted
    """
    sagemaker = boto3.client('sagemaker')
    cluster_name = os.environ.get('HYPER_POD_CLUSTER_NAME')
    
    try:
        # Check if the cluster exists
        describe_response = sagemaker.describe_cluster(ClusterName=cluster_name)
        cluster_status = describe_response.get('ClusterStatus', '')
        print(f"Current cluster status: {cluster_status}")
        
        # Delete the cluster
        print(f"Deleting HyperPod cluster: {cluster_name}")
        response = sagemaker.delete_cluster(ClusterName=cluster_name)
        print(f"Delete cluster response: {response}")
        
        # Poll until cluster is deleted
        print(f"Starting to poll for cluster deletion completion...")
        wait_time_seconds = 15  # Initial wait time between polls
        
        while True:
            try:
                describe_response = sagemaker.describe_cluster(ClusterName=cluster_name)
                cluster_status = describe_response.get('ClusterStatus', '')
                print(f"Cluster still exists. Current status: {cluster_status}")
                print(f"Waiting {wait_time_seconds} seconds before checking again...")
                import time
                time.sleep(wait_time_seconds)
            
            except ClientError as e:
                if e.response['Error']['Code'] == 'ResourceNotFound':
                    # Resource no longer exists - deletion is complete
                    print(f"Cluster {cluster_name} has been successfully deleted")
                    return {
                        'Message': f'Cluster {cluster_name} successfully deleted'
                    }
                else:
                    # For other client errors, log and re-raise
                    print(f"Client error while polling: {str(e)}")
                    raise
            except Exception as e:
                print(f"Error while polling for deletion: {str(e)}")
                raise
    
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceNotFound':
            # Resource already doesn't exist
            print(f"Cluster {cluster_name} not found, nothing to delete")
            return {
                'Message': f'Cluster {cluster_name} not found, nothing to delete'
            }
        else:
            # For other client errors, log and re-raise
            print(f"Client error during deletion: {str(e)}")
            raise
    except Exception as e:
        print(f"Error deleting cluster: {str(e)}")
        raise


def on_delete(event):
    """
    Handle Delete request to clean up files created during cluster creation
    """
    try:
        s3 = boto3.client('s3')
        bucket = os.environ.get('S3_BUCKET_NAME')
        if not bucket:
            print("S3_BUCKET_NAME environment variable not found")
            return {'Message': 'S3 bucket name not provided, nothing to delete'}
            
        deleted_files = []
        
        # Delete the cluster template yaml file
        template_key = 'hyperpod-cluster-template.yaml'
        try:
            s3.delete_object(Bucket=bucket, Key=template_key)
            deleted_files.append(f"s3://{bucket}/{template_key}")
            print(f"Successfully deleted s3://{bucket}/{template_key}")
        except ClientError as e:
            if e.response['Error']['Code'] == '404':
                print(f"File s3://{bucket}/{template_key} not found, nothing to delete")
            else:
                print(f"Error checking/deleting s3://{bucket}/{template_key}: {str(e)}")
        
        # Delete provisioning parameters JSON file if it exists
        # For SLURM orchestrator, this file is uploaded during cluster creation
        orchestrator_type = __get_orchestrator_type()
        if orchestrator_type == 'SLURM':
            # Determine the path for the provisioning_parameters.json file
            on_create_path = os.environ.get('ON_CREATE_PATH', '')
            path_prefix = ""
            if on_create_path:
                path_parts = on_create_path.rsplit('/', 1)
                if len(path_parts) > 1:
                    path_prefix = path_parts[0]
            
            # Set the file key with path prefix if available
            if path_prefix:
                params_key = f"{path_prefix}/provisioning_parameters.json"
            else:
                params_key = "provisioning_parameters.json"
                
            try:
                s3.delete_object(Bucket=bucket, Key=params_key)
                deleted_files.append(f"s3://{bucket}/{params_key}")
                print(f"Successfully deleted s3://{bucket}/{params_key}")
            except ClientError as e:
                if e.response['Error']['Code'] == '404':
                    print(f"File s3://{bucket}/{params_key} not found, nothing to delete")
                else:
                    print(f"Error checking/deleting s3://{bucket}/{params_key}: {str(e)}")
        
        if deleted_files:
            return {'Message': f'Successfully deleted files: {", ".join(deleted_files)}'}
        else:
            return {'Message': 'No files found to delete'}
            
    except Exception as e:
        print(f"Error in on_delete: {str(e)}")
        # Don't raise the exception, just return a message about it
        # This ensures CloudFormation deletion continues even if file cleanup fails
        return {'Message': f'Error deleting files: {str(e)}'}

def on_create(event):
    """
    Handle Create request to create a new HyperPod cluster
    """
    try:
        # Initialize response data
        response_data = {
            "Status": "SUCCESS",
            "Reason": "HyperPod cluster creation initiated successfully"
        }
        
        # Combine instance group settings from SSM
        instance_groups = combine_settings("instance-group-settings")
        
        # Enrich instance groups with additional configuration
        if instance_groups:
            instance_groups = enrich_instance_groups(instance_groups, isRig=False)
            # Filter out instance groups in AZs where their instance type is not available
            instance_groups = filter_instance_groups_by_az_availability(instance_groups)
        
        # Create the HyperPod cluster
        cluster_info = create_hyperpod_cluster(instance_groups)
        
        # Update response data with cluster information
        response_data.update(cluster_info)
        
        # Add status information
        response_data.update({
            'ClusterStatus': 'Creating',
            'Message': f'Cluster {cluster_info["ClusterName"]} creation initiated'
        })
        
        return response_data
        
    except Exception as e:
        print(f"Failed to create HyperPod cluster: {str(e)}")
        raise

def __get_orchestrator_type():
    """
    Get the orchestrator type from environment variables
    
    Returns:
    str: Orchestrator type ('EKS' or 'SLURM')
    """
    return os.environ.get('ORCHESTRATOR_TYPE', 'EKS')

def __get_provisioning_parameters_file(instance_groups):
    config_data = {
        "version": "1.0.0",
        "workload_manager": "slurm",
        "login_group": "my-login-group",
        "worker_groups": []
    }
    login_group = []
    compute_group = []
    controller_group = []
    compute_group_to_type = {}
    
    for instance_group in instance_groups:
        if "Login" == instance_group.get("InstanceGroupType"):
            login_group.append(instance_group["InstanceGroupName"])
        elif "Compute" == instance_group.get("InstanceGroupType"):
            compute_group.append(instance_group["InstanceGroupName"])
            compute_group_to_type[instance_group["InstanceGroupName"]] = instance_group["InstanceType"]
        elif "Controller" == instance_group.get("InstanceGroupType"):
            controller_group.append(instance_group["InstanceGroupName"])
        else:
            raise Exception(f"invalid type for instance group {instance_group['InstanceGroupName']}")

    if len(login_group) > 1 or len(controller_group) != 1:
        raise Exception(f"wrong number of instance group for login and controller type with config {instance_groups}")
    config_data = {
        "version": "1.0.0",
        "workload_manager": "slurm",
        "controller_group": controller_group[0],
        "worker_groups": [{"instance_group_name": groupName, "partition_name": compute_group_to_type[groupName]} for groupName in compute_group]
    }
    if login_group:
        config_data["login_group"] = login_group[0]
    enabled_fsx = os.environ.get('ENABLED_FSX', 'false').lower() == 'true'
    if enabled_fsx:
        config_data["fsx_dns_name"] = os.environ.get('FSX_DNS_NAME', '')
        config_data["fsx_mountname"] = os.environ.get('FSX_MOUNT_NAME', '')
        
        # Check if FSX values are provided
        if not config_data["fsx_dns_name"] or not config_data["fsx_mountname"]:
            print("Warning: FSX is enabled but FSX_DNS_NAME or FSX_MOUNT_NAME is missing")

    return json.dumps(config_data, indent=2)


def upload_slurm_provisioning_parameters_json(instance_groups):
    """
    Upload the generated provisioning_parameters json file, this file needs to reference the instanceGroup name.
    """
    if "SLURM" != __get_orchestrator_type():
        return
    s3 = boto3.client('s3')
    s3_bucket_name = os.environ.get("S3_BUCKET_NAME", "")
    on_create_path = os.environ.get('ON_CREATE_PATH', '')
    
    # Get path prefix from ON_CREATE_PATH if available
    path_prefix = ""
    if on_create_path:
        path_parts = on_create_path.rsplit('/', 1)
        if len(path_parts) > 1:
            path_prefix = path_parts[0]
    
    # Set the file key with path prefix if available
    if path_prefix:
        s3_file_key = f"{path_prefix}/provisioning_parameters.json"
    else:
        s3_file_key = "provisioning_parameters.json"
    
    s3.put_object(
        Bucket=s3_bucket_name,
        Key=s3_file_key,
        Body=__get_provisioning_parameters_file(instance_groups)
    )
    print(f"Uploaded provisioning_parameters.json to s3://{s3_bucket_name}/{s3_file_key}")

def generate_cluster_template_yaml(create_params):
    template = {
        "AWSTemplateFormatVersion": "2010-09-09",
        "Resources": {
            "NewHyperPodCluster": {
                "Type": "AWS::SageMaker::Cluster",
                "Properties": create_params
            }
        },
        "Outputs": {
            "HyperPodClusterArn": {
                "Description": "The ARN of the created SageMaker HyperPod cluster",
                "Value": {"Fn::GetAtt": ["NewHyperPodCluster", "ClusterArn"]}
            },
            "HyperPodClusterName": {
                "Description": "The name of the created SageMaker HyperPod cluster",
                "Value": {"Ref": "NewHyperPodCluster"}
            }
        }
    }
    return yaml.dump(template, sort_keys=False, default_flow_style=False, Dumper=NoAliasDumper)

def upload_cluster_template_to_s3(yaml_str):
    s3 = boto3.client('s3')
    bucket = os.environ['S3_BUCKET_NAME']
    key = 'hyperpod-cluster-template.yaml'

    s3.put_object(Bucket=bucket, Key=key, Body=yaml_str.encode('utf-8'), ContentType='text/yaml')
    return f"https://{bucket}.s3.amazonaws.com/{key}"
